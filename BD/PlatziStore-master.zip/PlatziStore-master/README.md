# PlatziStore
Ejercicio de PlatziStore para el curso básico de bases de datos de Platzi
